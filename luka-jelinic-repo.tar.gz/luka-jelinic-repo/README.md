# LUKA JELINIĆ — KEY GRIP / FILMOGRAPHY

Portfolio demo for **Luka Jelinić** — Zagreb-based key grip with 10+ years of credits on features, prestige TV, and commercial productions, including work with Janusz Kaminski (*Oslo*), Jacques Jouffert (*Jack Ryan 4*), Steve Lawes (*Strike Back*), Erol Zubčević (*HBO Success*), Thomas Dirnhofer (*Riesending*), Anna Katharina Buhler (*Faraway*), Oliver Ford (*Rimac : Verne*), and others.

Single-file static HTML site. No build step, no dependencies, no server.

---

## Live demo

Once GitHub Pages is enabled on this repo (Settings → Pages → Branch: main / root), the site will be served from:

```
https://monotomoo.github.io/Luka-Jelinic/
```

## Stack

- Vanilla HTML / CSS / JS — single file, ~1.5 MB
- **Three.js** (r128) — articulated technocrane in the `/rig` sandbox + hero teaser
- **GSAP** (3.12) — per-route transitions, glitch pulses, slate animations
- All visual assets inline as base64 — 8 project posters + on-set portrait

## Routes

- `/` — Index: hero, featured cards, departments, DOPs, quotes, booking form
- `/work` — Filmography: 10 credits, filterable + grid/contact/timeline views
- `/rig` — Operate the technocrane: drag to orbit, A/D/W/S/Q/E/Z/X to pose, R to roll, SPACE to slate
- `/services` — Six departments under one operator + booking form
- `/about` — Bio, on-set portrait, truck inventory, career progression timeline

## Local development

Just open `index.html` in any modern browser. No build, no server.

```bash
# Or serve with anything:
python3 -m http.server 8000
# then visit http://localhost:8000
```

## Browser support

Chromium / Firefox / Safari (latest). Mobile-responsive with breakpoints at 1100px and 720px. Custom cursor and most hover effects auto-disable on touch devices. `prefers-reduced-motion` honored.

---

Design and build: [Terminimal](https://terminimal.com)
